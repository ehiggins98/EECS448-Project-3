import numpy as np
import cv2 as cv

images = np.load('images.npy')
labels = np.load('labels.npy')

classes = {
    ':': 62,
    ';': 63,
    '<': 64,
    '=': 65,
    '>': 66,
    '?': 67,
    '!': 68,
    '"': 69,
    '%': 70,
    '&': 71,
    '\'': 72,
    '(': 73,
    ')': 74,
    '*': 75,
    '+': 76,
    ',': 77,
    '-': 78,
    '.': 79,
    '/': 80,
    '[': 81,
    ']': 82,
    '^': 83,
    '{': 84,
    '|': 85,
    '}': 86,
    '#': 87,
    '$': 88,
    '_': 89,
    '`': 90,
    '@': 91,
    '\\': 92,
    '~': 93
}
print(np.shape(images))
print(np.shape(labels))
for i in range(np.size(images, axis=0)):
    cv.imshow('test', images[i])
    for k, v in classes.items():
        if v == labels[i]:
            print(k)
            break
    cv.waitKey(0)
